import React, { useState } from "react";
import {
  Home,
  BarChart2,
  Shield,
  Settings,
  Thermometer,
  Droplet,
  Wind,
  Sun,
  CloudRain,
  CloudSnow,
} from "lucide-react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  ResponsiveContainer,
} from "recharts";
import CircularSlider from "@fseehawer/react-circular-slider";
import "./App.css";

const App = () => {
  const [activePage, setActivePage] = useState("dashboard");
  const [appData, setAppData] = useState({
    weather: {
      temperature: 22,
      humidity: 65,
      windSpeed: 12,
      weeklyForecast: [
        { day: "Mon", icon: <Sun size={16} />, temp: "25°C" },
        { day: "Tue", icon: <CloudRain size={16} />, temp: "18°C" },
        { day: "Wed", icon: <CloudRain size={16} />, temp: "20°C" },
        { day: "Thu", icon: <CloudSnow size={16} />, temp: "5°C" },
        { day: "Fri", icon: <Sun size={16} />, temp: "27°C" },
      ],
    },
    energyUsage: [
      { time: "6 AM", usage: 0.5 },
      { time: "9 AM", usage: 1.0 },
      { time: "12 PM", usage: 1.5 },
      { time: "3 PM", usage: 1.2 },
      { time: "6 PM", usage: 2.0 },
      { time: "9 PM", usage: 1.8 },
    ],
    boiler: {
      targetTemp: 70,
      currentTemp: 65,
      efficiency: 92,
      pressure: 1.5,
      weeklyUsage: 1250,
    },
    devices: [
      { id: 1, name: "Living Room Thermostat", status: "ON", targetTemp: 22 },
      { id: 2, name: "Smart Boiler", status: "ON", targetTemp: 70 },
    ],
    settings: {
      notifications: true,
      location: "Tel Aviv",
      temperatureUnit: "Celsius",
      sliders: {
        brightness: 50,
        volume: 30,
      },
    },
    analytics: {
      sliders: {
        energyThreshold: 75,
        waterUsageLimit: 50,
      },
    },
  });

  const renderSidebar = () => (
    <aside className="sidebar">
      <h1 className="sidebar-title">Smart Home</h1>
      <p className="energy-saved">15% Energy Saved</p>
      <nav>
        {["dashboard", "analytics", "devices", "settings"].map((id) => (
          <button
            key={id}
            onClick={() => setActivePage(id)}
            className={`nav-button ${activePage === id ? "active" : ""}`}
          >
            {id === "dashboard" ? <Home /> : id === "analytics" ? <BarChart2 /> : id === "devices" ? <Shield /> : <Settings />}
            <span>{id.charAt(0).toUpperCase() + id.slice(1)}</span>
          </button>
        ))}
      </nav>
    </aside>
  );

  const renderDashboard = () => (
    <div className="content-grid">
      <div className="card weather-card">
        <h2>Current Weather</h2>
        <div className="weather-details">
          <p>
            <Thermometer size={20} /> {appData.weather.temperature}°C
          </p>
          <p>
            <Droplet size={20} /> Humidity: {appData.weather.humidity}%
          </p>
          <p>
            <Wind size={20} /> Wind: {appData.weather.windSpeed} km/h
          </p>
        </div>
        <h3>Weekly Forecast</h3>
        <div className="weekly-forecast">
          {appData.weather.weeklyForecast.map((day, index) => (
            <div key={index} className="forecast-item">
              {day.icon}
              <p>{day.day}</p>
              <p>{day.temp}</p>
            </div>
          ))}
        </div>
        <h3>Temperature Prediction</h3>
        <ResponsiveContainer width="100%" height={200}>
          <LineChart
            data={appData.weather.weeklyForecast.map((day) => ({
              name: day.day,
              temperature: parseInt(day.temp, 10),
            }))}
          >
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="name" />
            <YAxis />
            <Tooltip />
            <Line type="monotone" dataKey="temperature" stroke="#8884d8" />
          </LineChart>
        </ResponsiveContainer>
      </div>
  
      <div className="card boiler-card">
        <h2>Boiler Control</h2>
        <p>Current: {appData.boiler.currentTemp}°C</p>
        <CircularSlider
          label="Target Temperature"
          width={200}
          min={40}
          max={90}
          progressColorFrom="#007bff"
          progressColorTo="#0056b3"
          knobColor="#ff7300"
          value={appData.boiler.targetTemp}
          onChange={(value) =>
            setAppData((prev) => ({
              ...prev,
              boiler: { ...prev.boiler, targetTemp: value },
            }))
          }
        />
        <p>Target: {appData.boiler.targetTemp}°C</p>
        <p>Efficiency: {appData.boiler.efficiency}%</p>
        <p>Pressure: {appData.boiler.pressure} bar</p>
      </div>
  
      <div className="card">
        <h2>Energy Usage</h2>
        <ResponsiveContainer width="100%" height={200}>
          <LineChart data={appData.energyUsage}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="time" />
            <YAxis />
            <Tooltip />
            <Line type="monotone" dataKey="usage" stroke="#8884d8" />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </div>
  );

  const renderDevices = () => (
    <div className="content-grid">
      {appData.devices.map((device) => (
        <div key={device.id} className="card device-card">
          <h3>{device.name}</h3>
          <p>Status: {device.status}</p>
          <CircularSlider
            label="°C"
            width={150}
            min={15}
            max={30}
            knobColor="#007bff"
            progressColorFrom="#00ff00"
            progressColorTo="#ff0000"
            value={device.targetTemp}
            onChange={(value) => setAppData((prev) => ({
              ...prev,
              devices: prev.devices.map((d) =>
                d.id === device.id ? { ...d, targetTemp: value } : d
              ),
            }))}
          />
          <p>Target: {device.targetTemp}°C</p>
        </div>
      ))}
    </div>
  );

  const renderSettings = () => (
    <div className="content-grid">
      <div className="card settings-card">
        <h2>Settings</h2>
        <label>
          Notifications:
          <input
            type="checkbox"
            checked={appData.settings.notifications}
            onChange={() =>
              setAppData({
                ...appData,
                settings: {
                  ...appData.settings,
                  notifications: !appData.settings.notifications,
                },
              })
            }
          />
        </label>
        <p>Location: {appData.settings.location}</p>
        <p>Temperature Unit: {appData.settings.temperatureUnit}</p>
      </div>
    </div>
  );
  const renderAnalytics = () => (
    <div className="content-grid">
      <div className="card analytics-card">
        <h2>Energy Analytics</h2>
        <ResponsiveContainer width="100%" height={200}>
          <LineChart data={appData.energyUsage}>
            <XAxis dataKey="time" />
            <YAxis />
            <Tooltip />
            <CartesianGrid strokeDasharray="3 3" />
            <Line type="monotone" dataKey="usage" stroke="#8884d8" />
          </LineChart>
        </ResponsiveContainer>
        <p>Daily Average: 1.3 kWh</p>
        <p>Monthly Savings: 15%</p>
      </div>
    </div>
  );


  const renderContent = () => {
    switch (activePage) {
      case "dashboard":
        return renderDashboard();
      case "analytics":
        return renderAnalytics();
      case "devices":
        return renderDevices();
      case "settings":
        return renderSettings();
      default:
        return null;
    }
  };

  return (
    <div className="app">
      {renderSidebar()}
      <main className="main-content">{renderContent()}</main>
    </div>
  );
};

export default App;
