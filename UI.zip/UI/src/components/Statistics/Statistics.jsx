import React from 'react';

function Statistics() {
  return (
    <div className="p-4">
      <h1 className="text-2xl font-bold">סטטיסטיקות</h1>
      <p>גרפים יפים</p>
    </div>
  );
}

export default Statistics;

